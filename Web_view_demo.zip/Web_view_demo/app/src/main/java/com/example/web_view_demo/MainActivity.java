package com.example.web_view_demo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    SwipeRefreshLayout swipeRefreshLayout;
    ConnectivityManager connectivityManager;
    NetworkInfo networkInfo;
    WebView wv1;
   // TextView tv1;
    ProgressDialog pd;
    ProgressBar progressBarweb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipeRefreshLayout=findViewById(R.id.swiperefresh);

        progressBarweb=findViewById(R.id.progress);
        wv1=findViewById(R.id.wv);

        swipeRefreshLayout.setOnRefreshListener(
                new SwipeRefreshLayout.OnRefreshListener() {
                    @Override
                    public void onRefresh() {
                       LoadWeb();
                    }
                }
        );

        // tv1=findViewById(R.id.tv);
        //tv1.setText("toolbar Demo");
         connectivityManager = (ConnectivityManager)
                getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        networkInfo = connectivityManager.getActiveNetworkInfo();


        if (networkInfo == null || !networkInfo.isConnected() || !networkInfo.isAvailable()) {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.alert_dialog);
            dialog.setCanceledOnTouchOutside(false);
            dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
            Button bt = dialog.findViewById(R.id.bt_try_again);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    recreate();

                }
            });
            dialog.show();
        }
        else {

            pd = new ProgressDialog(this);
            wv1 = findViewById(R.id.wv);          //it is used to find id
            pd.setMessage("Loading Please Wait...."); //it is used when page is load then thiss message show
            WebSettings ws = wv1.getSettings();
            ws.setJavaScriptEnabled(true);   //it is used to enabled javascript
            wv1.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    pd.show();   // it is used when the page is loading the progress dialouge is show

                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    pd.dismiss();   // it is used when the page is open the progress dialouge is dismiss
                }
            });    //set client webview
            wv1.loadUrl("https://orzoov.com/order-online/");

        }
        wv1.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBarweb.setVisibility(View.VISIBLE);
                progressBarweb.setProgress(newProgress);

                if (newProgress==100)
                {
                    progressBarweb.setVisibility(View.GONE);
                    pd.dismiss();
                }
                super.onProgressChanged(view, newProgress);
            }
        });
        wv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (networkInfo == null || !networkInfo.isConnected() || !networkInfo.isAvailable()) {
                    Dialog dialog = new Dialog(MainActivity.this);
                    dialog.setContentView(R.layout.alert_dialog);
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                    dialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
                    Button bt = dialog.findViewById(R.id.bt_try_again);
                    bt.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            recreate();

                        }
                    });
                    dialog.show();
                }
                else {

                    pd = new ProgressDialog(MainActivity.this);
                    wv1 = findViewById(R.id.wv);          //it is used to find id
                    pd.setMessage("Loading Please Wait...."); //it is used when page is load then thiss message show
                    WebSettings ws = wv1.getSettings();
                    ws.setJavaScriptEnabled(true);   //it is used to enabled javascript
                    wv1.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageStarted(WebView view, String url, Bitmap favicon) {
                            super.onPageStarted(view, url, favicon);
                            pd.show();   // it is used when the page is loading the progress dialouge is show

                        }

                        @Override
                        public void onPageFinished(WebView view, String url) {
                            super.onPageFinished(view, url);
                            pd.dismiss();   // it is used when the page is open the progress dialouge is dismiss
                        }
                    });    //set client webview
                    wv1.loadUrl("https://orzoov.com/order-online/");

                }
                wv1.setWebChromeClient(new WebChromeClient() {
                    @Override
                    public void onProgressChanged(WebView view, int newProgress) {
                        progressBarweb.setVisibility(View.VISIBLE);
                        progressBarweb.setProgress(newProgress);

                        if (newProgress==100)
                        {
                            progressBarweb.setVisibility(View.GONE);
                            pd.dismiss();
                        }
                        super.onProgressChanged(view, newProgress);
                    }
                });
            }
        });
    }
    @Override
    public void onBackPressed() {
        if(wv1.canGoBack()) //it is used when we press back then it go only last step back rather than completely go back
        {
            wv1.goBack();
        }
        else
        {
            super.onBackPressed();
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        if (networkInfo == null || !networkInfo.isConnected() || !networkInfo.isAvailable()) {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.alert_dialog);
            dialog.setCanceledOnTouchOutside(false);
            dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;
            Button bt = dialog.findViewById(R.id.bt_try_again);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    recreate();

                }
            });
            dialog.show();
        }
        else {

            pd = new ProgressDialog(this);
            wv1 = findViewById(R.id.wv);          //it is used to find id
            pd.setMessage("Loading Please Wait...."); //it is used when page is load then thiss message show
            WebSettings ws = wv1.getSettings();
            ws.setJavaScriptEnabled(true);   //it is used to enabled javascript
            wv1.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageStarted(WebView view, String url, Bitmap favicon) {
                    super.onPageStarted(view, url, favicon);
                    pd.show();   // it is used when the page is loading the progress dialouge is show

                }

                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);
                    pd.dismiss();   // it is used when the page is open the progress dialouge is dismiss
                }
            });    //set client webview
            wv1.loadUrl("https://orzoov.com/order-online/");

        }
        wv1.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBarweb.setVisibility(View.VISIBLE);
                progressBarweb.setProgress(newProgress);

                if (newProgress==100)
                {
                    progressBarweb.setVisibility(View.GONE);
                    pd.dismiss();
                }
                super.onProgressChanged(view, newProgress);
            }
        });
        wv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    public void LoadWeb(){
        wv1.getSettings().setJavaScriptEnabled(true);
        wv1.getSettings().setAppCacheEnabled(true);
        wv1.loadUrl("https://orzoov.com/order-online/");
        swipeRefreshLayout.setRefreshing(true);
        wv1.setWebViewClient(new WebViewClient()
        {
            public  void  onPageFinished(WebView view, String url){
                swipeRefreshLayout.setRefreshing(false);
            }

        });
    }
    }
